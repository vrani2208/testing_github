# Zepto Support Assistant

A RAG-based customer support assistant built using ChromaDB, LangGraph, Pydantic, and FastAPI.

## Project Overview

The Support Assistant answers customer questions using a Zepto policy knowledge base.

It supports two types of questions:

1. Policy questions - retrieve relevant information from Zepto policy documents.
2. General questions - answer directly without retrieving policy documents.

## Knowledge Base

The project contains 8 policy documents covering:

- Delivery Policy
- Returns & Refunds
- Membership
- Order Tracking
- Cancellation
- Damaged or Missing Items
- Gift Cards
- Customer Support

## Architecture

User Question
      |
      v
classify_intent
      |
      +------------------+
      |                  |
    policy             general
      |                  |
      v                  v
retrieve_and_answer   direct_answer
      |                  |
      +--------+---------+
               |
               v
      Structured Response
               |
               v
             FastAPI

## Technologies

- Python
- ChromaDB
- Sentence Transformers
- LangChain
- LangGraph
- Pydantic
- FastAPI
- Uvicorn
- Docker

## Project Structure

support_assistant/
├── docs/
│   ├── doc_01.txt
│   ├── doc_02.txt
│   ├── doc_03.txt
│   ├── doc_04.txt
│   ├── doc_05.txt
│   ├── doc_06.txt
│   ├── doc_07.txt
│   └── doc_08.txt
├── chroma_db/
├── rag.py
├── main.py
├── requirements.txt
├── Dockerfile
└── README.md

## RAG Workflow

Policy questions are searched against the ChromaDB collection zepto_docs.

The system retrieves relevant documents and returns the retrieved policy information.

## LangGraph Workflow

The LangGraph workflow contains three nodes:

- classify_intent
- retrieve_and_answer
- direct_answer

Policy questions are routed to document retrieval, while general questions are routed to the direct-answer node.

## API

### Health Check

GET /

Example response:

{
  "message": "Zepto Support Assistant is running"
}

### Ask a Question

POST /ask

Request:

{
  "question": "What is the delivery fee?"
}

Example response:

{
  "question": "What is the delivery fee?",
  "intent": "policy",
  "answer": "Zepto delivers grocery and household essentials...",
  "sources": [
    "Zepto policy documents"
  ]
}

## Running Locally

Install dependencies:

pip install -r requirements.txt

Start the FastAPI server:

uvicorn main:app --host 0.0.0.0 --port 8000

## Docker

Build the Docker image:

docker build -t zepto-support-assistant .

Run the container:

docker run -p 8000:8000 zepto-support-assistant

## Testing

Policy question:

What is the delivery fee?

The system classifies it as policy and retrieves information from the Zepto policy documents.

General question:

What is 10 + 20?

The system classifies it as general and returns:

10 + 20 = 30
